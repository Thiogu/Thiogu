import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
public class Main{
	public static void main(String[] args) {
		Main lst = new Main();
        Scanner scnr = new Scanner(System.in);
        int n; //number of int in list 
        n = scnr.nextInt();
        for(int i = 0; i < n; i++ ){
            int x = scnr.nextInt();
            lst.add(x);
        } //close for-loop
        lst.print();
        
        int q; //number of queries
        char query; int index,elt; //y = elt, x = index
        q = scnr.nextInt();
        for (int i = 0; i < q; i++){
            query = scnr.next().charAt(0);
            switch(query){
            case 'I':
            case 'i':
                index = scnr.nextInt();
                elt = scnr.nextInt();
                lst.insert(index,elt);
            break;
            case 'D':
            case 'd':
               // delete(lst,scnr);
            break;
            default: System.out.println("");
            break;
            }//close switch
            
        }//close for loop
    
	}//close main
	
	
	class Node{
	    int elt;
	    Node prev, next;
	    Node (int elt){ this.elt = elt;}
	}
	
	Node head, tail;
	int size;
	
	
	//add elt to list
	public boolean add(int elt){
	    Node nnd = new Node(elt);
	    //list is empty
	    if(head == null){
	       head = nnd;
	       tail = nnd;
	       head.prev = null;
	       tail.next = null;
	    }
	    else{
	        tail.next = nnd;
	        nnd.prev = tail;
	        nnd.next = null;
	        tail = nnd;
	        
	    }
	    size++;
	    return true;
	}
	
	public int size(){ return size;} 
	
	public int get(int index){
	    if (index < 0 ||  index >= size ) throw new IndexOutOfBoundsException();
	    Node tnd = head;
	    for(int i = 0; i < index; i++){
	        tnd = tnd.next;
	    }
	    return tnd.elt;
	}
	
	/*
     insert method
    */
	public void insert(int index, int data){
	    if (index <0 || index >= size) throw new IndexOutOfBoundsException();
	    if(index == size) add(data); //index == size
	    else{
	        Node tnd = head;
	        for(int i = 0; i < index; i++){
	            tnd = tnd.next;
	        }
	        Node nnd = new Node(data);
	        if(tnd == head){//tnd is first node
	            nnd.next = head;
	            head.prev = nnd;
	            head = nnd;
	        }
	        else{
	            Node prevNd = tnd.prev;
	            prevNd.next = nnd;
	            nnd.next = tnd;
	            tnd.prev = nnd;
	        }
	        
	    
	        size++;
	   }
	}
	
	public void print(){
	    Node tnd = head;
	    System.out.println(tnd.elt);
	    while(tnd.next != null){
	       tnd = tnd.next;
	       System.out.println(tnd.elt);
	   }
	}
	public void print(int x){
	    Node tnd = head;
	    for(int i = 0; i < size; i++){
	        tnd = tnd.next;
	        System.out.println(tnd.elt);
	    }
	}
	/*
     delete method
    */
	public void delete(int index){
	    
	}
}
